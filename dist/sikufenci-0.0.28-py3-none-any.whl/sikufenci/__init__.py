from .wordsegall_txt import *
from .wordsegall_txt import TCfenci_all