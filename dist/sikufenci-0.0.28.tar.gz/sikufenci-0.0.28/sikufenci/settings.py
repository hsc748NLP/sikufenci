'''
Author: your name
Date: 2021-04-14 21:26:33
LastEditTime: 2021-04-15 10:53:15
LastEditors: Please set LastEditors
Description: In User Settings Edit
FilePath: /BERT-CRF-Pytorch/processors/settings.py
'''
#LABELS=["X","O",'B-nr', 'I-nr', 'E-nr', 'S-nr', 'B-n', 'I-n', 'E-n', 'S-n', 'B-w', 'I-w', 'E-w', 'S-w', 'B-ns', 'I-ns', 'E-ns', 'S-ns', 'B-u', 'I-u', 'E-u', 'S-u', 'B-v', 'I-v', 'E-v', 'S-v', 'B-p', 'I-p', 'E-p', 'S-p', 'B-nx', 'I-nx', 'E-nx', 'S-nx', 'B-d', 'I-d', 'E-d', 'S-d', 'B-r', 'I-r', 'E-r', 'S-r', 'B-a', 'I-a', 'E-a', 'S-a', 'B-c', 'I-c', 'E-c', 'S-c', 'B-t', 'I-t', 'E-t', 'S-t', 'B-m', 'I-m', 'E-m', 'S-m', 'B-q', 'I-q', 'E-q', 'S-q', 'B-y', 'I-y', 'E-y', 'S-y', 'B-j', 'I-j', 'E-j', 'S-j', 'B-nc', 'I-nc', 'E-nc', 'S-nc', 'B-nrx', 'I-nrx', 'E-nrx', 'S-nrx', 'B-f', 'I-f', 'E-f', 'S-f', 'B-gv', 'I-gv', 'E-gv', 'S-gv', 'B-i', 'I-i', 'E-i', 'S-i',"[CLS]","[SEP]"]

LABELS=["X","O",'B','I','E','S',"[CLS]","[SEP]"]



